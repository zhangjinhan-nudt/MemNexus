"""Independent memory service. No SimpleMem or host SDK imports in the core."""

__version__ = "0.3.3"
