"""One source-bound answer table for factual and compositional questions.

Quote checks prove provenance, not entailment. Keep that distinction explicit.
The renderer cannot silently discard an accepted item; unresolved slots remain
in the receipt. No benchmark categories, answers, or domain aliases live here.
"""

import re
from datetime import date
from typing import Literal

from pydantic import Field

from .models import Contract, Hit


class Support(Contract):
    source_id: int = Field(ge=1)
    quote: str = Field(min_length=1, max_length=700)


class DateDifference(Contract):
    start: date
    end: date
    unit: Literal["days", "weeks", "years"]

    def value(self) -> str:
        if self.end < self.start:
            raise ValueError("Time difference must have ordered endpoints")
        if self.unit == "years":
            if (self.start.month, self.start.day) != (self.end.month, self.end.day):
                raise ValueError("Whole-year difference requires equal month and day")
            number = self.end.year - self.start.year
        else:
            days = (self.end - self.start).days
            if self.unit == "weeks" and days % 7:
                raise ValueError("Do not round an inexact interval to whole weeks")
            number = days // 7 if self.unit == "weeks" else days
        return f"{number} {self.unit}"


class SupportedValue(Contract):
    value: str = Field(min_length=1, max_length=700)
    supports: list[Support] = Field(min_length=1, max_length=8)
    calculation: DateDifference | None = None


class AnswerSlot(Contract):
    target: str = Field(min_length=1, max_length=500)
    values: list[SupportedValue] = Field(default_factory=list, max_length=30)
    missing: str = Field(default="", max_length=500)


class AnswerTable(Contract):
    slots: list[AnswerSlot] = Field(min_length=1, max_length=20)


def answer_type(question: str) -> str:
    q = question.casefold()
    if re.search(r"how (?:many|long).*?(?:weeks?|days?|years?|months?|hours?)|相隔|多久", q):
        return "duration"
    if re.search(r"\b(?:when|what year|which year|what date)\b|何时|哪年", q):
        return "date"
    if re.search(r"how many|number of|几个|多少", q):
        return "count"
    return "text"


def validate_table(table: AnswerTable, sources: list[Hit], targets: list[str], kind: str) -> None:
    if [slot.target for slot in table.slots] != targets:
        raise ValueError("Return every requested target exactly once and in order")
    for slot in table.slots:
        if not slot.values and not slot.missing:
            raise ValueError("An empty target requires an explicit missing-evidence reason")
        for item in slot.values:
            dates = set()
            for support in item.supports:
                if support.source_id > len(sources):
                    raise ValueError("Unknown source number")
                events = sources[support.source_id - 1].metadata.get("source_events", [])
                matched = [e for e in events if not e.get("context_only") and support.quote in e["text"]]
                if not matched:
                    raise ValueError("Every value needs an exact original, non-question evidence quote")
                for event in matched:
                    dates.add(str(event.get("occurred_at", ""))[:10])
                    dates.update(re.findall(r"\b\d{4}-\d{2}-\d{2}\b", event["text"]))
                    for derivation in event.get("time_derivations", []):
                        # An interval boundary is not a known exact event date.
                        if derivation["precision"] == "day":
                            dates.add(derivation["start"])
            if item.calculation:
                if kind != "duration":
                    raise ValueError("Date difference only answers a duration query")
                if not {item.calculation.start.isoformat(), item.calculation.end.isoformat()} <= dates:
                    raise ValueError("Calculation endpoints need source-bound dates")
                item.value = item.calculation.value()
            if kind == "duration" and not re.search(r"\b(?:days?|weeks?|months?|years?|hours?|minutes?)\b|天|周|月|年", item.value, re.IGNORECASE):
                raise ValueError("Duration answers must express a duration, not an event name")
            if kind == "count" and not re.search(r"\d|\b(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|none)\b", item.value, re.IGNORECASE):
                raise ValueError("Count answers must contain a number or a supported bound")


def render_table(table: AnswerTable) -> str:
    values = list(dict.fromkeys(item.value.strip() for slot in table.slots for item in slot.values))
    return "; ".join(values) if values else "Not mentioned in the conversation"
