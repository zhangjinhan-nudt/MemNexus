"""
LLM Client - Handles all LLM interactions
"""
import json
import os
import time
from pathlib import Path
from typing import List, Dict, Any, Optional
from openai import OpenAI
from simplemem.core.settings import settings as config


class BudgetExceededError(BaseException):
    """A provider request cannot fit inside this experiment component's cap."""


class TruncatedOutputError(BaseException):
    """Stop the experiment after its one declared length-recovery request."""


class LLMClient:
    """
    Unified LLM client interface
    """
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        base_url: Optional[str] = None,
        enable_thinking: Optional[bool] = None,
        use_streaming: Optional[bool] = None
    ):
        self.api_key = api_key or config.OPENAI_API_KEY
        self.model = model or config.LLM_MODEL
        self.base_url = base_url or config.OPENAI_BASE_URL
        self.enable_thinking = enable_thinking if enable_thinking is not None else config.ENABLE_THINKING
        self.use_streaming = use_streaming if use_streaming is not None else config.USE_STREAMING
        self.input_price_rmb = float(getattr(config, "INPUT_PRICE_RMB_PER_MILLION_TOKENS", 0))
        self.output_price_rmb = float(getattr(config, "OUTPUT_PRICE_RMB_PER_MILLION_TOKENS", 0))
        self.cost_limit_rmb = float(os.getenv("EXPERIMENT_COMPONENT_BUDGET_RMB", "0"))
        self.usage = {
            "provider_attempts": 0,
            "retry_attempts": 0,
            "provider_errors": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "cost_rmb": 0.0,
        }
        self.telemetry = []
        self.ledger_path = os.getenv("EXPERIMENT_USAGE_LEDGER_PATH", "").strip()

        # Initialize OpenAI client with optional base_url
        client_kwargs = {"api_key": self.api_key}
        if self.base_url:
            client_kwargs["base_url"] = self.base_url
            print(f"Using custom OpenAI base URL: {self.base_url}")

        if self.enable_thinking:
            print(f"Deep thinking mode enabled")

        # self.client = OpenAI(**client_kwargs)
        self.client = OpenAI(
            base_url=self.base_url,
            api_key=self.api_key,
            max_retries=0,  # All real HTTP attempts must pass our budget check.
            timeout=180,
        )

    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.2,
        response_format: Optional[Dict[str, str]] = None,
        max_retries: int = 3,
        _output_limit: Optional[int] = None,
    ) -> str:
        """
        Standard chat completion with optional thinking mode and retry mechanism
        """
        kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": config.TEMPERATURE,
            "max_tokens": _output_limit or config.MAX_TOKENS,
        }

        if response_format:
            kwargs["response_format"] = response_format

        if self.base_url and "api.deepseek.com" in self.base_url:
            kwargs["extra_body"] = {"thinking": {"type": "disabled"}}

        estimated_input = len(json.dumps(messages, ensure_ascii=False).encode("utf-8")) + 256
        projected = (
            estimated_input * self.input_price_rmb
            + kwargs["max_tokens"] * self.output_price_rmb
        ) / 1_000_000

        # Enable thinking mode if configured (for Qwen and compatible models only)
        # Only add enable_thinking parameter for Qwen API (identified by base_url)
        is_qwen_api = self.base_url and "dashscope.aliyuncs.com" in self.base_url
        
        if is_qwen_api:
            # Qwen API requires explicit enable_thinking parameter
            # - Streaming + thinking: enable_thinking=True
            # - Non-streaming: enable_thinking=False (required, not optional)
            # - JSON format: enable_thinking=False (incompatible with thinking mode)
            if self.use_streaming and self.enable_thinking and not response_format:
                kwargs["extra_body"] = {"enable_thinking": True}
            else:
                # Explicitly set to False for non-streaming calls or JSON format
                kwargs["extra_body"] = {"enable_thinking": False}
        # For OpenAI and other APIs, don't add extra_body parameters

        # Retry mechanism
        last_exception = None
        for attempt in range(max_retries):
            if self.cost_limit_rmb and self.usage["cost_rmb"] + projected > self.cost_limit_rmb:
                raise BudgetExceededError(
                    f"SimpleMem component budget would be exceeded: "
                    f"{self.usage['cost_rmb'] + projected:.6f} > {self.cost_limit_rmb:.6f} RMB"
                )
            started = time.perf_counter()
            self.usage["provider_attempts"] += 1
            if attempt:
                self.usage["retry_attempts"] += 1
            self.usage["reserved_rmb"] = projected
            self._persist_usage()
            self._trace({"event": "request", "attempt": self.usage["provider_attempts"], "body": kwargs})
            try:
                # Use streaming if configured
                if self.use_streaming:
                    kwargs["stream"] = True
                    return self._handle_streaming_response(**kwargs)
                else:
                    response = self.client.chat.completions.create(**kwargs)
                    provider_usage = response.usage
                    if provider_usage is None:
                        self.usage["cost_rmb"] += projected
                        self.usage["reserved_rmb"] = 0.0
                        self._persist_usage()
                        raise BudgetExceededError("Provider returned no usage; reserved maximum cost was charged")
                    input_tokens = int(getattr(provider_usage, "prompt_tokens", 0) or 0)
                    output_tokens = int(getattr(provider_usage, "completion_tokens", 0) or 0)
                    cost = (
                        input_tokens * self.input_price_rmb
                        + output_tokens * self.output_price_rmb
                    ) / 1_000_000
                    self.usage["input_tokens"] += input_tokens
                    self.usage["output_tokens"] += output_tokens
                    self.usage["cost_rmb"] += cost
                    self.usage["reserved_rmb"] = 0.0
                    self.telemetry.append(
                        {
                            "attempt": self.usage["provider_attempts"],
                            "input_tokens": input_tokens,
                            "output_tokens": output_tokens,
                            "cost_rmb": cost,
                            "latency_ms": (time.perf_counter() - started) * 1000,
                            "status": "completed",
                        }
                    )
                    self._persist_usage()
                    if hasattr(response, "model_dump"):
                        self._trace({"event": "response", "attempt": self.usage["provider_attempts"],
                                     "body": response.model_dump(mode="json")})
                    ceiling = int(os.getenv("EXPERIMENT_TRUNCATION_MAX_TOKENS", "0"))
                    if getattr(response.choices[0], "finish_reason", None) == "length" and ceiling:
                        if _output_limit is not None or ceiling <= kwargs["max_tokens"]:
                            raise TruncatedOutputError("Response truncated after bounded length recovery")
                        self.usage["length_recovery_attempts"] = self.usage.get("length_recovery_attempts", 0) + 1
                        self._persist_usage()
                        return self.chat_completion(
                            messages, temperature, response_format, max_retries,
                            _output_limit=ceiling,
                        )
                    return response.choices[0].message.content
                
                # kwargs["stream"] = True
                # return self._handle_streaming_response(**kwargs)
                    
            except Exception as e:
                if self.usage.get("reserved_rmb", 0):
                    # A network error can still have incurred upstream usage.
                    self.usage["cost_rmb"] += self.usage["reserved_rmb"]
                    self.usage["unknown_usage_upper_bound_rmb"] = self.usage.get("unknown_usage_upper_bound_rmb", 0) + self.usage["reserved_rmb"]
                    self.usage["reserved_rmb"] = 0.0
                self.usage["provider_errors"] += 1
                self._persist_usage()
                self._trace({"event": "error", "attempt": self.usage["provider_attempts"], "error_type": type(e).__name__})
                self.telemetry.append(
                    {
                        "attempt": self.usage["provider_attempts"],
                        "latency_ms": (time.perf_counter() - started) * 1000,
                        "status": "error",
                        "error_type": type(e).__name__,
                    }
                )
                if isinstance(e, BudgetExceededError):
                    raise
                # print(e)
                last_exception = e
                if attempt < max_retries - 1:
                    wait_time = (2 ** attempt)  # Exponential backoff: 1s, 2s, 4s
                    print(f"LLM API call failed (attempt {attempt + 1}/{max_retries}): {type(e).__name__}")
                    print(f"Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    print(f"LLM API call failed after {max_retries} attempts: {type(e).__name__}")
        
        # If all retries failed, raise the last exception
        raise last_exception

    def _persist_usage(self) -> None:
        if not self.ledger_path:
            return
        path = Path(self.ledger_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(self.usage, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(path)

    def _trace(self, record: dict) -> None:
        if self.ledger_path:
            path = Path(self.ledger_path).with_suffix(".calls.jsonl")
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps({"time_unix": time.time(), **record}, ensure_ascii=False) + "\n")

    def _handle_streaming_response(self, **kwargs) -> str:
        """
        Handle streaming response and collect full content
        """
        full_content = []
        stream = self.client.chat.completions.create(**kwargs)

        # for chunk in stream:
        #     if chunk.choices is not None:
        #         print(chunk.choices[0].delta.content)
        
        # print('---------')

        for chunk in stream:
            # print(chunk)
            # fix list index out of range
            if len(chunk.choices) > 0 and chunk.choices[0].delta.content is not None:
                content = chunk.choices[0].delta.content
                full_content.append(content)
                # print(full_content)
                # Optional: print streaming content in real-time
                # print(content, end='', flush=True)
        # print(full_content)
        print()
        return ''.join(full_content)

    def extract_json(self, text: str) -> Any:
        """
        Extract JSON from LLM response with robust parsing
        Supports multiple formats:
        1. Pure JSON
        2. ```json ... ```
        3. ``` ... ``` (generic code block)
        4. JSON embedded in text with common prefixes
        5. Multiple JSON objects (returns first valid one)
        """
        if not text or not text.strip():
            raise ValueError("Empty response received")

        text = text.strip()

        # A truncated top-level array must never be reinterpreted as its first
        # complete object. This previously turned partial extraction output into
        # apparently valid but incomplete memory.
        unfenced = text
        if unfenced.lower().startswith("```json"):
            unfenced = unfenced[7:].lstrip()
        elif unfenced.startswith("```"):
            unfenced = unfenced[3:].lstrip()
        if unfenced.startswith("["):
            result = self._extract_balanced_json(unfenced, "[")
            if result is not None:
                return result
            raise ValueError("Truncated or invalid top-level JSON array")

        # Remove common LLM prefixes/suffixes
        common_prefixes = [
            "Here's the JSON:",
            "Here is the JSON:",
            "The JSON is:",
            "JSON:",
            "Result:",
            "Output:",
            "Answer:",
        ]
        for prefix in common_prefixes:
            if text.lower().startswith(prefix.lower()):
                text = text[len(prefix):].strip()

        # Try direct parsing first
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        # Try extracting JSON from ```json ... ``` block
        if "```json" in text.lower():
            # Case insensitive search for ```json
            start_marker = "```json"
            start_idx = text.lower().find(start_marker)
            if start_idx != -1:
                start = start_idx + len(start_marker)
                # Find the closing ```
                end = text.find("```", start)
                if end != -1:
                    json_str = text[start:end].strip()
                    try:
                        return json.loads(json_str)
                    except json.JSONDecodeError as e:
                        # Try to clean up common issues
                        json_str = self._clean_json_string(json_str)
                        try:
                            return json.loads(json_str)
                        except json.JSONDecodeError:
                            pass

        # Try extracting from generic ``` ... ``` code block
        if "```" in text:
            start = text.find("```") + 3
            # Skip language identifier if present
            newline = text.find("\n", start)
            if newline != -1 and newline - start < 20:
                start = newline + 1
            end = text.find("```", start)
            if end != -1:
                json_str = text[start:end].strip()
                try:
                    return json.loads(json_str)
                except json.JSONDecodeError:
                    # Try to clean up
                    json_str = self._clean_json_string(json_str)
                    try:
                        return json.loads(json_str)
                    except json.JSONDecodeError:
                        pass

        # Try finding balanced JSON object/array by scanning for { or [
        for start_char in ['{', '[']:
            result = self._extract_balanced_json(text, start_char)
            if result is not None:
                return result

        # Last resort: try to find any JSON-like structure and clean it
        for start_char in ['{', '[']:
            start_idx = text.find(start_char)
            if start_idx != -1:
                # Extract a large chunk and try to parse
                chunk = text[start_idx:]
                cleaned = self._clean_json_string(chunk)
                try:
                    return json.loads(cleaned)
                except json.JSONDecodeError:
                    pass

        raise ValueError(f"Failed to extract valid JSON from response. First 300 chars: {text[:300]}...")

    def _clean_json_string(self, json_str: str) -> str:
        """
        Clean common issues in JSON strings from LLM output
        """
        # Remove trailing commas before } or ]
        import re
        json_str = re.sub(r',(\s*[}\]])', r'\1', json_str)

        # Remove comments (// and /* */)
        json_str = re.sub(r'//.*?$', '', json_str, flags=re.MULTILINE)
        json_str = re.sub(r'/\*.*?\*/', '', json_str, flags=re.DOTALL)

        return json_str.strip()

    def _extract_balanced_json(self, text: str, start_char: str) -> Any:
        """
        Extract a balanced JSON object or array starting with start_char
        """
        end_char = '}' if start_char == '{' else ']'
        start_idx = text.find(start_char)

        if start_idx == -1:
            return None

        # Track depth to find matching closing bracket
        depth = 0
        in_string = False
        escape_next = False

        for i in range(start_idx, len(text)):
            char = text[i]

            # Handle string escaping
            if escape_next:
                escape_next = False
                continue

            if char == '\\':
                escape_next = True
                continue

            # Handle strings (don't count brackets inside strings)
            if char == '"':
                in_string = not in_string
                continue

            if in_string:
                continue

            # Count depth
            if char == start_char:
                depth += 1
            elif char == end_char:
                depth -= 1
                if depth == 0:
                    json_str = text[start_idx:i+1]
                    try:
                        return json.loads(json_str)
                    except json.JSONDecodeError:
                        # Try cleaning and parsing again
                        cleaned = self._clean_json_string(json_str)
                        try:
                            return json.loads(cleaned)
                        except json.JSONDecodeError:
                            # Continue searching for next occurrence
                            break

        return None
